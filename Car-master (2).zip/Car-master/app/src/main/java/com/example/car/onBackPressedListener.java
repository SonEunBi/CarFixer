package com.example.car;

public interface onBackPressedListener {
    void onBackPressed();
}
