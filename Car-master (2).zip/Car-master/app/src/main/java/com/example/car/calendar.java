package com.example.car;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class calendar extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendar);
    }
}