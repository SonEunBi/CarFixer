package com.example.car;

class CenterList {


    private int car_profile1;
    private String car_name1;
    private String car_address1;
    private String car_phone1;
    private String car_distance1;

    public int getCar_profile1() {
        return car_profile1;
    }

    public void setCar_profile1(int car_profile1) {
        this.car_profile1 = car_profile1;
    }

    public String getCar_name1() {
        return car_name1;
    }

    public void setCar_name1(String car_name1) {
        this.car_name1 = car_name1;
    }

    public String getCar_address1() {
        return car_address1;
    }

    public void setCar_address1(String car_address1) {
        this.car_address1 = car_address1;
    }

    public String getCar_phone1() {
        return car_phone1;
    }

    public void setCar_phone1(String car_phone1) {
        this.car_phone1 = car_phone1;
    }

    public String getCar_distance1() {
        return car_distance1;
    }

    public void setCar_distance1(String car_distance1) {
        this.car_distance1 = car_distance1;
    }

    public CenterList(int car_profile1, String car_name1, String car_phone1, String car_address1, String car_distance1) {
        this.car_profile1 = car_profile1;
        this.car_name1 = car_name1;
        this.car_phone1 = car_phone1;
        this.car_distance1 = car_distance1;
        this.car_address1 = car_address1;
    }

//
//    public Drawable getProfile() {
//        return this.profile;
//    }
//
//    public void setProfile(Drawable profile) {
//        profile = profile;
//    }
//
//    public String getCenterName() {
//        return this.centerName;
//    }
//
//    public void setCenterName(String centerName) {
//        centerName = centerName;
//    }
//
//    public String getPhone() {
//        return this.phone;
//    }
//
//    public void setPhone(String phone) {
//        phone = phone;
//    }
//
//    public String getAddress() {
//        return this.address;
//    }
//
//    public void setAddress(String address) {address = address;
//    }
//
//    public String getDistance() {
//        return this.distance;
//    }
//
//    public void setDistance(String distance) {
//        distance = distance;
//    }
//
//
//


}
