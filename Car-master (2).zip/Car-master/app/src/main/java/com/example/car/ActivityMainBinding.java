package com.example.car;

public class ActivityMainBinding {
}
